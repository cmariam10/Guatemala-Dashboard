% Calculate spatial distribution of amenities and productivity in the world
% based on GD model and 2000 data on population and wages
% using the procedure discussed in Appendix B.7
% We denote a(r)/u0(r) by a, and tau0(r) by tau throughout the code

clc; clear all;

% parameter values
xbar = 360;        % size of spatial grid
ybar = 180;        % size of spatial grid
alpha = 0.06;      % elasticity of productivity w.r.t. local population
lambda = 0.32;     % congestion externalities
gamma1 = 0.319;    % elasticity of tomorrow's productivity w.r.t. today's innovation
gamma2 = 0.99246;  % elasticity of tomorrow's productivity w.r.t. today's productivity
mu = 0.8;          % labor share in production
nu = 0.15;         % intercept parameter in innovation cost function   % nu = 0.15;
ksi = 125;         % elasticity of innovation costs w.r.t. innovation
sigma = 4;         % elasticity of substitution
theta = 6.5;       % trade elasticity
epsilon = 0.4;     % epsilon0 in Appendix B.7
rad = 6371;        % radius of Earth
psi = 1.8;         % subjective wellbeing parameter
khi = lambda - (alpha-1+(lambda+gamma1/ksi-(1-mu))*theta) / (1+2*theta);
kappa1 = ((mu*ksi+gamma1)/ksi)^(-(mu+gamma1/ksi)*theta) * mu^(mu*theta) * (ksi*nu/gamma1)^(-gamma1/ksi*theta) * gamma(1-(sigma-1)/theta)^(theta/(sigma-1));

% get data
%H0 = csvread('H0.csv');    % distribution of land
load('H0.mat')
pop0 = csvread('l.csv'); % distribution of population in period 0
w = csvread('w.csv');    % distribution of wages in period 0
%S = sign(H);

% Define vectors
earth_indices = find(H0 > 0);
n = length(earth_indices);
H0 = H0(earth_indices);
pop0 = pop0(earth_indices);
w = w(earth_indices);

lbar = sum(pop0);   % total population

% transform population into population per unit of land
pop0 = pop0 ./ H0;

% get trade costs
load('trmult_reduced.mat');

a = ones(n,1);
l = lbar*ones(n,1)/n;
wbar = sum(w)/n;

error_outer = 1e+10;      % dist0 tilde in Appendix B.7

% Pre-computed quantities
prefactor1 = w.^(1+theta) .* pop0.^(1-lambda*theta).* H0;
prefactor2 = kappa1^(-1/theta) * wbar^((1+2*theta)/theta) *...
                    w.^(-1) .* pop0.^lambda;
    
while (error_outer >= 1e+10)
    
    epsilon = epsilon/2;
    
    % solve equations (32) and (31) for a and tau ("inner loop")
    error_inner1 = 1;     % dist1 in Appendix B.7 using equation (60)
        
    while (error_inner1 >= 1e-02)

        rhs = trmult_reduced*(prefactor1.*a.^(theta-epsilon));
        
        aa = prefactor2 .* rhs.^(-1/theta);

        error_inner1 = sum((aa-a).^2);  % calculate dist1 
        disp(['error_outer*10^(-10)=' num2str(error_outer*10^(-10)) ' ; error_inner1=' num2str(error_inner1)])
        a = aa;
    end;
    
    tau = wbar^(-(1+2*theta)) .* a.^theta .* H0 .* w.^(1+2*theta) .*...
                    pop0.^(1-alpha-(lambda+gamma1/ksi-(1-mu))*theta);
    
    % solve for population distribution under a and tau, using equation
    % (24)
    error_inner2 = 10;  % dist_t 
    while (error_inner2 >= 1)
        
        input_inner2 = a.^((theta^2)/(1+2*theta)) .*...
                        H0.^(theta/(1+2*theta)) .*...
                        tau.^((1+theta)/(1+2*theta)) .*...
                        l.^(1-lambda*theta+(1+theta)/(1+2*theta)*(alpha-1+(lambda+gamma1/ksi-(1-mu))*theta));
                    
        rhs = trmult_reduced*input_inner2;
        
        ll = a.^((1+theta)/(khi*(1+2*theta))) .*...
                        H0.^(-1/(khi*(1+2*theta))) .*...
                        tau.^(1/(khi*(1+2*theta))) .*...
                        rhs.^(1/(khi*theta));
        
        % calculate dist_t
        error_inner2 = sum( (  (H0.*l - H0.*ll) / sum(H0.*ll)*lbar ).^2    );

        l = ll;
    end;
    l = l / sum(H0.*ll) * lbar;                                            % rescale L so that H*L sum to lbar

    error_outer = sum((H0.*l - H0.*pop0).^2);                              % calculate dist0 tilde

end;

a_H0 = a;
tau_H0 = tau;

% Save distribution as .mat files
save('a_H0','a_H0','-v7.3');
save('tau_H0','tau_H0','-v7.3');

% Plot logs of a, tau0 and a/u0
ubar = csvread('ubar.csv');  % Utility levels from Deaton Stone
ubar(isnan(ubar)) = 0;
ubar(isinf(ubar)) = 0;
u0 = exp(psi*ubar(earth_indices));
a_norm = a.*u0;
figure
varm = -Inf*ones(180,360);
varm(earth_indices) = log(tau);
colormap(jet);
imagesc(varm);
colorbar('eastoutside');
figure
varm = -Inf*ones(180,360);
varm(earth_indices) = log(a_norm);
colormap(jet);
imagesc(varm);
colorbar('eastoutside');
figure
varm = -Inf*ones(180,360);
varm(earth_indices) = log(a);
colormap(jet);
imagesc(varm);
colorbar('eastoutside');
