% This code: 
% 1. Loads all the necessary data to run the model
% 2. Runs the model, computes and plots summary statistics 
% 3. Runs the model backwards, computes correlations with the data
% 4. Saves all the output to disk

% The code runs only on initially emerged cells, as given by earth_indices
% and uses amenities and productivity calibrated on H0.

%% 1. Load all the necessary data to run the model for scenario 2

clear all;
% Set all global variables that will be defined in initialize
global H0 a a_norm m2 C_vect tau0 pop0 pop5 pop5_fertadj popminus5 popminus10 ubar...
    trmult_reduced n earth_indices indicator_sea subs subs_vect beta tail_bands...
    ind_islands alpha theta Omega;

initialize(1);
  
%% 2. Choose distribution of land for simulation

% Land distribution
H = H0(earth_indices);

% Set the number of periods
nb_per = 600;

%% 3. Run the model and obtain summary statistics
[realgdp_w, u_w, u2_w, prod_w , phi_w , PDV_u_w , PDV_u2_w, ...
    PDV_realgdp_w, migr_cell, migr_ctry, l, u, u2, ...
    tau, realgdp ] = results(H,nb_per);

%% 4. Plot the time series and maps, and save them
plots(H, realgdp_w, u_w, u2_w, prod_w, l, u, tau, realgdp )

%% 5. Run model backward in time

% Set the number of periods
nb_back = 180;

% Simulate model backwards
[ l_b, u_b, w_b, tau_b, phi_b, realgdp_b ] = backward(H0(earth_indices),nb_back);

% Calculate correlations between population levels, log levels, changes, log changes
display('CORRELATIONS WITH 1995 DATA - CELL LEVEL');
corr(popminus5(earth_indices),H0(earth_indices).*l_b(:,5))
corr(log(popminus5(earth_indices)),log(H0(earth_indices).*l_b(:,5)))
corr(pop0(earth_indices)-popminus5(earth_indices),pop0(earth_indices)-H0(earth_indices).*l_b(:,5))
corr(log(pop0(earth_indices))-log(popminus5(earth_indices)),log(pop0(earth_indices))-log(H0(earth_indices).*l_b(:,5)))
display('CORRELATIONS WITH 1990 DATA - CELL LEVEL');
corr(popminus10(earth_indices),H0(earth_indices).*l_b(:,10))
corr(log(popminus10(earth_indices)),log(H0(earth_indices).*l_b(:,10)))
corr(pop0(earth_indices)-popminus10(earth_indices),pop0(earth_indices)-H0(earth_indices).*l_b(:,10))
corr(log(pop0(earth_indices))-log(popminus10(earth_indices)),log(pop0(earth_indices))-log(H0(earth_indices).*l_b(:,10)))

display('CORRELATIONS WITH 1995 DATA - COUNTRY LEVEL');
popminus5_ctry_d = accumarray(C_vect,popminus5(earth_indices));
popminus5_ctry_m = accumarray(C_vect,H0(earth_indices).*l_b(:,5));
pop0_ctry = accumarray(C_vect,pop0(earth_indices));
corr(popminus5_ctry_d,popminus5_ctry_m)
corr(log(popminus5_ctry_d),log(popminus5_ctry_m))
corr(pop0_ctry-popminus5_ctry_d,pop0_ctry-popminus5_ctry_m)
corr(log(pop0_ctry)-log(popminus5_ctry_d),log(pop0_ctry)-log(popminus5_ctry_m))
display('CORRELATIONS WITH 1990 DATA - COUNTRY LEVEL');
popminus10_ctry_d = accumarray(C_vect,popminus10(earth_indices));
popminus10_ctry_m = accumarray(C_vect,H0(earth_indices).*l_b(:,10));
corr(popminus10_ctry_d,popminus10_ctry_m)
corr(log(popminus10_ctry_d),log(popminus10_ctry_m))
corr(pop0_ctry-popminus10_ctry_d,pop0_ctry-popminus10_ctry_m)
corr(log(pop0_ctry)-log(popminus10_ctry_d),log(pop0_ctry)-log(popminus10_ctry_m))

%% 6. Save all the output to disk

% Save output of the model         
% The name of the folder has to be chosen accordingly

save('Output\realgdp_w','realgdp_w','-v7.3');
save('Output\u_w','u_w','-v7.3');
save('Output\u2_w','u2_w','-v7.3');
save('Output\prod_w','prod_w','-v7.3');
save('Output\phi_w','phi_w','-v7.3');
save('Output\PDV_u_w','PDV_u_w','-v7.3');
save('Output\PDV_u2_w','PDV_u2_w','-v7.3');
save('Output\PDV_realgdp_w','PDV_realgdp_w','-v7.3');
save('Output\migr_cell','migr_cell','-v7.3');
save('Output\migr_ctry','migr_ctry','-v7.3');
save('Output\l','l','-v7.3');
save('Output\u','u','-v7.3');
save('Output\realgdp','realgdp','-v7.3');
save('Output\tau','tau','-v7.3');
save('Output\l_b','l_b','-v7.3');
