function [] = initialize(load_trmult)

%% 0. Declare global variables
 global H0 a m2 C_vect tau0 pop0 pop5 pop5_fertadj popminus5 popminus10 ubar...
     trmult_reduced n earth_indices indicator_sea subs beta tail_bands...
     ind_islands alpha theta Omega vect_omega;

%% 1. Load initial land, amenities, productivity, moving costs, and population
% New H0, new amenities and productivities consistent with H0
load('H0.mat');
a_H0 = load('a_H0.mat');
%a = a_H0;
a = a_H0.a_H0;
tau_H0 = load('tau_H0.mat');
%tau0 = tau_H0;
tau0 = tau_H0.tau_H0;
m2 = load('m2.mat');
m2 = m2.m2;
pop0 = csvread('l.csv');                                                   % distribution of population in period 0
pop5 = csvread('pop5.csv');                                                % distribution of population in period 5
popminus5 = csvread('popminus5.csv');                                      % distribution of population in period -5
popminus10 = csvread('popminus10.csv');                                    % distribution of population in period -10
pop5_fertadj = csvread('pop5_fertadj.csv');                                % period 5 population, fertility-adjusted
clear a_H0 tau_H0;

%% 2. Find coordinates of emerged cells on the coarse grid
earth_indices = find(H0 > 0);
n = length(earth_indices);
indicator_sea = (H0==0);

%% 3. Load and shape utility levels
ubar = csvread('ubar.csv');  % Utility levels from Deaton Stone

% Remove Nans and Infs from ubar
ubar(isnan(ubar)) = 0;
ubar(isinf(ubar)) = 0;

%% 4. Load trmult or not

% Bilateral trade cost on earth cells at t=0 only
if (load_trmult == 1)
    load('trmult_reduced.mat');
end

%% 5. Load and Manipulate countries to get rid of missing indices
C = csvread('C.csv');  % Countries

C_stock = C(earth_indices);
indices = unique(C_stock);
C_stock_2 = C_stock;
for i=1:length(indices)
    C_stock_2(C_stock==indices(i)) = i;
end
C(earth_indices) = C_stock_2;

% subs contains the indicators of the countries (+1 to avoid zero).
% it can be used later to create maps aggregated per country
% C_vect contains the index of each emerged cell's country
subs = reshape(C,180*360,1)+1;
C_vect = C(earth_indices);

%% 6. Set other global variables

% Discount factor for present discounted values
beta = 0.965;
% Tail probabilities in the tails of the confidence bands
tail_bands = 0.2;
% Set alpha, theta, Omega to usual value
alpha = 0.06;
theta = 6.5;
Omega = 0.5;

end