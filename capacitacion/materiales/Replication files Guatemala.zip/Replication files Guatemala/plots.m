function [ ] = ...
    plots(...
              H, ...
              realgdp_w, ...
              u_w, ...
              u2_w, ...
              prod_w, ...
              l, ...
              u, ...
              tau, ...
              realgdp )

% Creates time series plots and maps:
    % 1 Time series plots of world aggregates
    % 2. Creates maps at the cell-level
         
% Takes as inputs some of outputs of result_rlz.m

global m2 earth_indices tail_bands alpha theta Omega;

%% 1. World aggregates

T = 600;

% calculate world productivity and real GDP, correlations
prworld = prod_w;
rgdpworld = realgdp_w;
uworld = u_w;
u2world = u2_w;
prgrowth = zeros(T,1);
rgdpgrowth = zeros(T,1);
ugrowth = zeros(T,1);
u2growth = zeros(T,1);
corr_rgdppop = zeros(T,2,2);
corr_prpop = zeros(T,2,2);
corr_prrgdp = zeros(T,2,2);
for t = 1:T;
    if (t > 1)
        prgrowth(t) = prworld(t) / prworld(t-1);
        rgdpgrowth(t) = rgdpworld(t) / rgdpworld(t-1);
        ugrowth(t) = uworld(t) / uworld(t-1);
        u2growth(t) = u2world(t) / u2world(t-1);
    end;
    rgdp_vector = realgdp(:,t);
    pop_vector = l(:,t);
    pr_vector = (tau(:,t).*l(:,t).^alpha).^(1/theta);
    rgdp_vector = rgdp_vector(H > 0);
    pop_vector = pop_vector(H > 0);
    pr_vector = pr_vector(H > 0);
    corr_rgdppop(t,:,:) = corr(log(rgdp_vector),log(pop_vector));
    corr_prpop(t,:,:) = corr(log(pr_vector),log(pop_vector));
    corr_prrgdp(t,:,:) = corr(log(pr_vector),log(rgdp_vector));
end;

% graphs
figure
subplot(2,3,1)
plot(2:T,prgrowth(2:T));
title('Growth rate of productivity')
xlabel('Time')

subplot(2,3,2)
plot(2:T,rgdpgrowth(2:T));
title('Growth rate of real GDP')
xlabel('Time')

subplot(2,3,3)
plot(2:T,ugrowth(2:T));
title('Growth rate of utility (u)')
xlabel('Time')

subplot(2,3,4)
plot(1:T,log(prworld(1:T)));
title('Ln world average productivity')
xlabel('Time')

subplot(2,3,5)
plot(1:T,log(rgdpworld(1:T)));
title('Ln world average real GDP')
xlabel('Time')

subplot(2,3,6)
plot(1:T,log(uworld(1:T)));
title('Ln world utility (u)')
xlabel('Time')

figure
subplot(2,2,1)
plot(2:T,ugrowth(2:T));
title('Growth rate of utility (u)')
xlabel('Time')

subplot(2,2,2)
plot(3:T,u2growth(3:T));
title('Growth rate of E(u*\epsilon)')
xlabel('Time')

subplot(2,2,3)
plot(1:T,log(uworld(1:T)));
title('Ln world utility (u)')
xlabel('Time')

subplot(2,2,4)
plot(1:T,log(u2world(1:T)));
title('Ln E(u*\epsilon)')
xlabel('Time')

figure
subplot(1,3,1)
plot(corr_rgdppop(:,1,2));
title('Corr (log real GDP per capita, log population density)')
xlabel('Time')

subplot(1,3,2)
plot(corr_prpop(:,1,2));
title('Corr (log productivity, log population density)')
xlabel('Time')

subplot(1,3,3)
plot(corr_prrgdp(:,1,2));
title('Corr (log productivity, log real GDP per capita)')
xlabel('Time')

%% 2. Cell-level maps

    % Plot cell-level maps at time 1
    maps(l(:,1), u(:,1), (tau(:,1).*l(:,1).^alpha).^(1/theta), realgdp(:,1), 1);
    
    % Plot cell-level maps at time 200
    maps(l(:,200), u(:,200), (tau(:,200).*l(:,200).^alpha).^(1/theta), realgdp(:,200), 200);
    
    % Plot cell-level maps at time 600
    maps(l(:,600), u(:,600), (tau(:,600).*l(:,600).^alpha).^(1/theta), realgdp(:,600), 600);

end
