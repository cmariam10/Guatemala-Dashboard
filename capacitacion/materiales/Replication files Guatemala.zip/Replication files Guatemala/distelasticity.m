% Calculate distance elasticity of trade flows in the simulated data

clear all;

% parameters
alpha = 0.06;
lambda = 0.32;
gamma1 = 0.319;
mu = 0.8;
ksi = 125;
theta = 6.5;
rad = 6371;
psi = 1.8;

% earth indices
load('H0.mat')
earth_indices = find(H0 > 0);
n = length(earth_indices);
H = H0(earth_indices);
C = csvread('C.csv');
Ctry = C(earth_indices);

% distances
distmat = zeros(180,360,180,360);
disp('Calculate distances...');
for i = 1:180;
    i
    for j = 1:360;
        if (H0(i,j) > 0)
            for k = 1:180;
                for l = 1:360;
                    if (H0(k,l) > 0)
                        lat1 = i/180*pi;
                        lat2 = k/180*pi;
                        long1 = j/180*pi;
                        long2 = l/180*pi;
                        distmat(i,j,k,l) = rad*real(acos(sin(lat1)*sin(lat2)+cos(long1-long2)*cos(lat1)*cos(lat2)));
                    end;
                end;
            end;
        end;
    end;
end;
distmat = reshape(distmat,180*360,180*360);
distmat_reduced = distmat(earth_indices,earth_indices);
clear distmat;

% trade flows, GDP
trademat_reduced = zeros(n,n);
gdp1_reduced = zeros(n,n);
gdp2_reduced = zeros(n,n);
pop1_reduced = zeros(n,n);
pop2_reduced = zeros(n,n);
cell1_reduced = zeros(n,n);
cell2_reduced = zeros(n,n);
ctry1_reduced = zeros(n,n);
ctry2_reduced = zeros(n,n);
a_H0 = load('a_H0.mat');
a = a_H0.a_H0;
ubar = csvread('ubar.csv');  % Utility levels from Deaton Stone
ubar(isnan(ubar)) = 0;
ubar(isinf(ubar)) = 0;
u0 = exp(psi*ubar(earth_indices));
a_norm = a.*u0;
load('Output\NF_1000\l.mat');
load('Output\NF_1000\tau.mat');
load('Output\NF_1000\u.mat');
load('trmult_reduced.mat');
w = a_norm.^(-theta/(1+2*theta)) .* u(:,1).^(theta/(1+2*theta)) .* H.^(-1/(1+2*theta)) .*...
    tau(:,1).^(1/(1+2*theta)) .* l(:,1).^((alpha-1+(lambda+gamma1/ksi-(1-mu))*theta)/(1+2*theta));
trsharesum = trmult_reduced * (tau(:,1).*l(:,1).^(alpha-(1-mu-gamma1/ksi)*theta).*w.^(-theta));
disp('Calculate trade flows...');
for i = 1:n;
    for j = 1:n;
        if (i ~= j)
            trademat_reduced(i,j) = tau(j,1)*l(j,1)^(alpha-(1-mu-gamma1/ksi)*theta)*w(j)^(-theta) *...
                trmult_reduced(i,j) / trsharesum(i) * w(i) * H(i) * l(i,1);
            gdp1_reduced(i,j) = w(i) * H(i) * l(i,1);
            gdp2_reduced(i,j) = w(j) * H(j) * l(j,1);
            pop1_reduced(i,j) = H(i) * l(i,1);
            pop2_reduced(i,j) = H(j) * l(j,1);
            cell1_reduced(i,j) = i;
            cell2_reduced(i,j) = j;
            ctry1_reduced(i,j) = Ctry(i);
            ctry2_reduced(i,j) = Ctry(j);
        end;
    end;
end;
clear trmult_reduced;

% save results
save('gravity.mat','-v7.3');

% load results
load('gravity.mat');

% regress log trade on log distance
distv = reshape(distmat_reduced,n^2,1);
tradev = reshape(trademat_reduced,n^2,1);
gdp1v = reshape(gdp1_reduced,n^2,1);
gdp2v = reshape(gdp2_reduced,n^2,1);
pop1v = reshape(pop1_reduced,n^2,1);
pop2v = reshape(pop2_reduced,n^2,1);
cell1v = reshape(cell1_reduced,n^2,1);
cell2v = reshape(cell2_reduced,n^2,1);
ctry1v = reshape(ctry1_reduced,n^2,1);
ctry2v = reshape(ctry2_reduced,n^2,1);
zro = sign(distv.*tradev.*gdp1v.*gdp2v.*pop1v.*pop2v);
for i = 1:n^2;
    i
    if (ctry1v(i) ~= ctry2v(i))
        zro(i) = 0;
    end;
end;
distv(zro == 0) = [];
tradev(zro == 0) = [];
gdp1v(zro == 0) = [];
gdp2v(zro == 0) = [];
pop1v(zro == 0) = [];
pop2v(zro == 0) = [];
b = regress(log(tradev),[ones(length(tradev),1) log(gdp1v) log(gdp2v) log(pop1v) log(pop2v) log(distv)]);
