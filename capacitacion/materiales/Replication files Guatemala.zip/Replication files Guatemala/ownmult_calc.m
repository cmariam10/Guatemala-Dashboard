% Calculate approximation of own trade multipliers

clear all;
xbar = 360;
ybar = 180;
theta = 6.5;
upsilon = 2.56 / theta;

% load mesh, instantaneous trade costs
[vertex,faces] = read_mesh('triangulated_sphere');
Sig = csvread('Sig.csv');

% perform fast marching to calculate and save bilateral distances
clear options;
options.W = ones(129242,1);
dist = zeros(ybar,xbar,ybar,xbar);
for i = 1:ybar;
    i
    for j = 1:xbar;
        [D,St,Q] = perform_fast_marching_mesh(vertex,faces,(i-1)*xbar+j,options);
        for l = 1:ybar;
            for m = 1:xbar;
                dist(i,j,l,m) = D((l-1)*xbar+m);
            end;
        end;
    end;
end;
save('dist.mat','dist','-v7.3');

% load('dist.mat');

% calculate approximate average distance of crossing a cell along a diagonal
distn = zeros(ybar,xbar);
for i = 1:ybar;
    if (i < ybar)
        for j = 1:xbar;
            if (j == 1)
                distn(i,j) = (dist(i,j,i+1,xbar) + dist(i,j,i+1,j+1)) / 2;
            elseif (j == xbar)
                distn(i,j) = (dist(i,j,i+1,j-1) + dist(i,j,i+1,1)) / 2;
            else
                distn(i,j) = (dist(i,j,i+1,j-1) + dist(i,j,i+1,j+1)) / 2;
            end;
        end;
    else
        if (j == 1)
            distn(i,j) = (dist(i,j,i-1,xbar) + dist(i,j,i-1,j+1)) / 2;
        elseif (j == xbar)
            distn(i,j) = (dist(i,j,i-1,j-1) + dist(i,j,i-1,1)) / 2;
        else
            distn(i,j) = (dist(i,j,i-1,j-1) + dist(i,j,i-1,j+1)) / 2;
        end;
    end;
end;

% calculate own trade multipliers from distances, save them
% 0.3684 = 0.521/sqrt(2) is the expected distance between two
% random points inside a cell with unit diagonal
ownmult = (0.3684*Sig.*distn).^(-upsilon*theta);
csvwrite('ownmult.csv',ownmult);

% change diagonal of trade multiplier matrix to own trade multipliers
load('H0.mat');
earth_indices = find(H0(:) > 0);
n = length(earth_indices);
ownmult_reduced = ownmult(earth_indices);
load('trmult_reduced.mat');
for i = 1:n;
    trmult_reduced(i,i) = ownmult_reduced(i);
end;
