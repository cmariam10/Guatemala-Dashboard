% Compute bilateral trade costs between any two locations in the Earth
% using Fast Marching Algorithm

clear all;
xbar = 360;
ybar = 180;
theta = 6.5;
upsilon = 1;

% load and display mesh
[vertex,faces] = read_mesh('triangulated_sphere');

figure
plot_mesh(vertex,faces);
shading interp;

% load world map
load('H0.mat');
S = sign(H0);

% load and display instantaneous trade costs
Sig = csvread('Sig.csv');
Sg = zeros(129242,1);
for i = 1:ybar;
    for j = 1:xbar;
        Sg((i-1)*xbar+j) = Sig(i,j);
    end;
end;
for i = 1:ybar-1;
    for j = 1:xbar;
        if (j > 1)
            Sg(64800+(i-1)*xbar+j) = (Sig(i,j-1)+Sig(i,j)+Sig(i+1,j-1)+Sig(i+1,j))/4;
        else
            Sg(64800+(i-1)*xbar+j) = (Sig(i,1)+Sig(i,xbar)+Sig(i+1,1)+Sig(i+1,xbar))/4;
        end;
    end;
end;
Sg(129241) = sum(Sig(1,:)) / xbar;
Sg(129242) = sum(Sig(ybar,:)) / xbar;

figure
imagesc(Sig);
colorbar

% perform fast marching to calculate and save bilateral trade costs
clear options;
options.W = Sg;
% options.W = Sg/4288;
trmult = zeros(ybar,xbar,ybar,xbar);
for i = 1:ybar;
    i
    for j = 1:xbar;
        if (S(i,j) == 1)
            [D,St,Q] = perform_fast_marching_mesh(vertex,faces,(i-1)*xbar+j,options);
            for l = 1:ybar;
                for m = 1:xbar;
                    if (D((l-1)*xbar+m) > 0)
                        trmult(i,j,l,m) = D((l-1)*xbar+m)^(-upsilon*theta);
                    else
                        trmult(i,j,l,m) = 0;
                    end;
%                     trmult(i,j,l,m) = exp(-D((l-1)*xbar+m)*upsilon*theta);
                end;
            end;
        end;
    end;
end;

save('trmult.mat','trmult','-v7.3');

% plot log of trade multiplier from Princeton, NJ
figure
imagesc(log(trmult(:,:,50,106)));
colorbar
