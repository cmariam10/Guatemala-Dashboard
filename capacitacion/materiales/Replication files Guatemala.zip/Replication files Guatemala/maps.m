function [  ] = maps( series1, series2, series3, series4, t)
                                         
% Creates 4 maps at time t
% The series must be in order: l(t),
%                              u(t), 
%                              prod(t),
%                              realgdp(t)

global earth_indices;

%% 1. Take logs of variables
series1 = log(series1);
series2 = log(series2);
series3 = log(series3);
series4 = log(series4);

%% 2. Plot the figures 

 for i = 1:4
    figure
    
    % Integrate figures title in the plot
    series_name =  [ 'series' num2str(i) ];
    var = eval(series_name);
    if i == 1
        ti = suptitle(['Log population density, time ' num2str(t)]);
        title_name = 'PD';
    elseif i==2
        ti = suptitle(['Log utility, time ' num2str(t)]);
        title_name = 'U';
    elseif i==3
        ti = suptitle(['Log productivity, time ' num2str(t)]);
        title_name = 'PR';
    else
        ti = suptitle(['Log real GDP per capita ' num2str(t)]);
        title_name = 'RO';
    end
    
    % Set position of title
    P = get(ti,'Position');
    set(ti,'Position',[P(1) P(2)+0.03 P(3)]);

    varm = -Inf*ones(180,360);
    varm(earth_indices) = var;
    colormap(jet);
    
    if (i == 1)
        imagesc(varm,[-10 21]);
    elseif ((i == 3) && (t == 1))
        imagesc(varm,[-3 7]);
    elseif ((i == 3) && (t == 600))
        imagesc(varm,[11 21]);
    elseif ((i == 4) && (t == 1))
        imagesc(varm,[-4 3]);
    else
        imagesc(varm);
    end;
    
    colorbar('eastoutside')
        
%% 3. Save output to disk

filename = ...
['Maps\' title_name '_NF_' num2str(t) '_1000.fig'];
saveas(gcf,filename);
    
hold off   
end

end
