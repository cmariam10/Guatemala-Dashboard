function [realgdp_w, ...
          u_w, ...
          u2_w, ...
          prod_w, ...
          phi_w, ...
          PDV_u_w, ...
          PDV_u2_w, ...
          PDV_realgdp_w, ...
          migr_cell, ...
          migr_ctry, ...
          l, ...
          u, ...
          u2, ...
          tau, ...
          realgdp ] = ....
          results( H, T )

% This function runs the model; it also creates several detailed description of the results

%% 1. Initialize the inputs of the simulation

tic;
start_result = toc;

global a a_norm m2 C_vect pop0 pop5 pop5_fertadj beta n H0 earth_indices alpha theta Omega;

%% 2. Create the output arrays in which the ouput of the simulations are stored
                
% Create the arrays in which the results will be stored
% Nomenclature of the names of the variables
% _w for world aggregates
% PDV stands for present discounted value


    % World-level time series
    realgdp_w = zeros(T,1);
    u_w = zeros(T,1);
    u2_w = zeros(T,1);
    prod_w = zeros(T,1);
    phi_w = zeros(T,1);
    PDV_u_w = 0;
    PDV_u2_w = 0;
    PDV_realgdp_w = 0;

%% 3. Run the simulations and copy the results to the arrays created in 2.   
    
%% 3.1 Simulate the model
[ l, w, u, tau, phi, realgdp ] = model(H,T);

% Calculate correlations between population levels, log levels, changes, log changes
display('CORRELATIONS - CELL LEVEL');
corr(pop5(earth_indices),H.*l(:,5))
corr(log(pop5(earth_indices)),log(H.*l(:,5)))
corr(pop5(earth_indices)-pop0(earth_indices),H.*l(:,5)-pop0(earth_indices))
corr(log(pop5(earth_indices))-log(pop0(earth_indices)),log(H.*l(:,5))-log(pop0(earth_indices)))

display('CORRELATIONS - COUNTRY LEVEL');
pop5_ctry_d = accumarray(C_vect,pop5(earth_indices));
pop5_ctry_m = accumarray(C_vect,H.*l(:,5));
pop0_ctry = accumarray(C_vect,pop0(earth_indices));
corr(pop5_ctry_d,pop5_ctry_m)
corr(log(pop5_ctry_d),log(pop5_ctry_m))
corr(pop5_ctry_d-pop0_ctry,pop5_ctry_m-pop0_ctry)
corr(log(pop5_ctry_d)-log(pop0_ctry),log(pop5_ctry_m)-log(pop0_ctry))

% Calculate correlation between population levels, log levels, changes, log changes
display('CORRELATIONS (FERTILITY-ADJUSTED) - CELL LEVEL');
corr(pop5_fertadj(earth_indices),H.*l(:,5))
corr(log(pop5_fertadj(earth_indices)),log(H.*l(:,5)))
corr(pop5_fertadj(earth_indices)-pop0(earth_indices),H.*l(:,5)-pop0(earth_indices))
corr(log(pop5_fertadj(earth_indices))-log(pop0(earth_indices)),log(H.*l(:,5))-log(pop0(earth_indices)))

display('CORRELATIONS (FERTILITY-ADJUSTED) - COUNTRY LEVEL');
pop5_ctry_fertadj = accumarray(C_vect,pop5_fertadj(earth_indices));
corr(pop5_ctry_fertadj,pop5_ctry_m)
corr(log(pop5_ctry_fertadj),log(pop5_ctry_m))
corr(pop5_ctry_fertadj-pop0_ctry,pop5_ctry_m-pop0_ctry)
corr(log(pop5_ctry_fertadj)-log(pop0_ctry),log(pop5_ctry_m)-log(pop0_ctry))

%% 3.2 Compute world aggregates

% realgdp, u, u2, prod, phi, present discounted values
u2 = zeros(n,T);
m1 = m2.^(-1);
for t = 1:T;
    u2(:,t) = sum(u(:,t).^(1/Omega) .* m2.^(-1/Omega))^Omega * m2;   % E[u*epsilon], welfare measure of equation (4)
    u_w(t) = sum(u(:,t).*H.*l(:,t));
    u2_w(t) = sum(u2(:,t).*H.*l(:,t));
    realgdp_w(t) = sum(realgdp(:,t).*H.*l(:,t));
    prod_w(t) = sum((tau(:,t).*H.*l(:,t).^(1+alpha)).^(1/theta));
    phi_w(t) = sum(phi(:,t).*H.*l(:,t));
    PDV_u_w = PDV_u_w + beta^(t-1) * u_w(t);
    PDV_u2_w = PDV_u2_w + beta^(t-1) * u2_w(t);
    PDV_realgdp_w = PDV_realgdp_w + beta^(t-1) * realgdp_w(t);
end;
if (beta*u_w(T)/u_w(T-1) < 1)
    PDV_u_w = PDV_u_w + (beta^T*u_w(T)^2/u_w(T-1)) / (1-beta*u_w(T)/u_w(T-1));
else
    PDV_u_w = NaN;
end;
if (beta*u2_w(T)/u2_w(T-1) < 1)
    PDV_u2_w = PDV_u2_w + (beta^T*u2_w(T)^2/u2_w(T-1)) / (1-beta*u2_w(T)/u2_w(T-1));
else
    PDV_u2_w = NaN;
end;
if (beta*realgdp_w(T)/realgdp_w(T-1) < 1)
    PDV_realgdp_w = PDV_realgdp_w + (beta^T*realgdp_w(T)^2/realgdp_w(T-1)) /...
        (1-beta*realgdp_w(T)/realgdp_w(T-1));
else
    PDV_realgdp_w = NaN;
end;

%% 3.3 Share of migrants
migr_cell = zeros(T,1);
for t = 1:T;
    summ = 0;
    for j = 1:n;
        if (t == 1)
            if (H(j)*l(j,1) > pop0(earth_indices(j)))
                summ = summ + H(j)*l(j,1) - pop0(earth_indices(j));
            end;
        else
            if (H(j)*l(j,t) > H(j)*l(j,t-1))
                summ = summ + H(j)*l(j,t) - H(j)*l(j,t-1);
            end;
        end;
    end;
    migr_cell(t) = summ / sum(sum(pop0));
end;

migr_ctry = zeros(T,1);
pop_ctry_m = zeros(168,T);
for t = 1:T;
    pop_ctry_m(:,t) = accumarray(C_vect,H.*l(:,t));
    summ = 0;
    for i = 1:168;
        if (t == 1)
            if (pop_ctry_m(i,1) > pop0_ctry(i))
                summ = summ + pop_ctry_m(i,1) - pop0_ctry(i);
            end;
        else
            if (pop_ctry_m(i,t) > pop_ctry_m(i,t-1))
                summ = summ + pop_ctry_m(i,t) - pop_ctry_m(i,t-1);
            end;
        end;
    end;
    migr_ctry(t) = summ / sum(pop0_ctry);
end;

end_result = toc;
    time_result = end_result - start_result;
    disp(['The function without parfor took ' num2str(time_result) 'seconds'])

end
