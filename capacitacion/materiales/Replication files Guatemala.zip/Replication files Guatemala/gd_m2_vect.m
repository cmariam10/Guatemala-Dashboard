% Calculate spatial distribution of moving costs in the world
% based on GD model and 2000 data on population and wages
% using the procedure discussed in Section 4.5

clc; clear all;

% parameter values
xbar = 360;        % size of spatial grid
ybar = 180;        % size of spatial grid
alpha = 0.06;      % elasticity of productivity w.r.t. local population
lambda = 0.32;     % congestion externalities
gamma1 = 0.319;    % elasticity of tomorrow's productivity w.r.t. today's innovation
gamma2 = 0.99246;  % elasticity of tomorrow's productivity w.r.t. today's productivity
eta = 1;           % parameter driving scale of technology diffusion
mu = 0.8;          % labor share in production
nu = 0.15;         % intercept parameter in innovation cost function   % nu = 0.15;
ksi = 125;         % elasticity of innovation costs w.r.t. innovation
sigma = 4;         % elasticity of substitution
theta = 6.5;       % trade elasticity
Omega = 0.5;       % location taste heterogeneity parameter
rad = 6371;        % radius of Earth
psi = 1.8;         % subjective wellbeing parameter
khi = lambda - (alpha-1+(lambda+gamma1/ksi-(1-mu))*theta) / (1+2*theta);

% Get data
load('H0.mat')
a_H0 = load('a_H0.mat');
% a = a_H0;
a = a_H0.a_H0;
tau_H0 = load('tau_H0.mat');
% tau0 = tau_H0;
tau0 = tau_H0.tau_H0;
pop0 = csvread('l.csv'); % distribution of population in period 0
pop1 = csvread('pop1.csv'); % distribution of population in period 1

% Define vectors
earth_indices = find(H0 > 0);
n = length(earth_indices);
H0 = H0(earth_indices);
indicator_sea = (H0==0);
pop0 = pop0(earth_indices);
pop1 = pop1(earth_indices);

lbar = sum(sum(pop0));   % total population
% Corrected from lbar = sum(pop0)

% transform population into population per unit of land
pop0 = pop0 ./ H0;
pop1 = pop1 ./ H0;

% get trade costs
load('trmult_reduced.mat');

% load and shape utility levels
ubar = csvread('ubar.csv');  % Utility levels from Deaton Stone
ubar(isnan(ubar)) = 0;
ubar(isinf(ubar)) = 0;

% calculate utility from subjective wellbeing
u0 = exp(psi*ubar(earth_indices));

% back out amenities
a_norm = a.*u0;

% update productivity from period 0 to period 1 levels according to
% equation (8) and (12) and (13)
avgprod = sum(sum(tau0)) / n;
% load('diffmult_reduced.mat');
% avgprod = diffmult_reduced * tau0;
tau1 = eta * tau0.^gamma2 .* avgprod.^(1-gamma2) .* (gamma1/(nu*(gamma1+mu*ksi)) * pop0).^(gamma1*theta/ksi);

% initial guess for m2
m2 = ones(n,1);

% Pre-computed quantities
prefactor1 = a_norm.^(theta^2/(1+2*theta)) .* tau1.^((1+theta)/(1+2*theta)) .*...
    H0.^(theta/(1+2*theta) - Omega*theta^2/(1+2*theta)) .*...
    pop1.^(1-lambda*theta+(1+theta)/(1+2*theta)*(alpha-1+(lambda+gamma1/ksi-(1-mu))*theta)-theta^2/(1+2*theta)*Omega);
prefactor2 = a_norm .* tau1.^(1/(1+theta)) .* H0.^(-(1/(1+theta)+Omega)) .*...
    pop1.^(-khi*(1+2*theta)/(1+theta) - Omega);

% solve equations (7) and (24) for u and m2 ("inner loop")
error = 1;

while (error >= 1e-13)

    rhs = trmult_reduced*(prefactor1.*m2.^(-theta^2/(1+2*theta)));
    
    mm2 = prefactor2 .* rhs.^((1+2*theta)/(theta*(1+theta)));
    
    error = sum((mm2-m2).^2);  % calculate dist
    disp(['error = ' num2str(error)])
    m2 = mm2;
end;

% normalize m2 such that minimum equals one
m2 = m2 / min(m2);

% save distribution as .mat file
save('m2','m2','-v7.3');

% plot log of m2
figure
varm = -Inf*ones(180,360);
varm(earth_indices) = log(m2);
colormap(jet);
imagesc(varm,[0 14]);
colorbar('eastoutside');
