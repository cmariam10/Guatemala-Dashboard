function [ l, u, w, tau, phi, realgdp ] = backward( H, T )

% Simulate GD model for world with given dist of amenities & productivity
% backward in time

global a_norm m2 tau0 pop0 trmult_reduced earth_indices H0 n alpha theta Omega;

%% 1. Initialize parameters and output

% Normalize population to population density
popdens = pop0;
popdens(earth_indices) =  popdens(earth_indices)./H0(earth_indices);
popdens(isinf(popdens)) = 0;
popdens(isnan(popdens)) = 0;

% Parameter values
lbar = 5.9174e+09; % total population
% lbar = sum(sum(pop0));
lambda = 0.32;     % congestion externalities
gamma1 = 0.319;    % elasticity of tomorrow's productivity w.r.t. today's innovation
gamma2 = 0.99246;  % elasticity of tomorrow's productivity w.r.t. today's productivity
mu = 0.8;          % labor share in production
nu = 0.15;         % intercept parameter in innovation cost function   % nu = 0.15;
ksi = 125;         % elasticity of innovation costs w.r.t. innovation
sigma = 4;         % elasticity of substitution
rad = 6371;        % radius of Earth
khi = lambda - (alpha-1+(lambda+gamma1/ksi-(1-mu))*theta) / (1+2*theta);
kappa1 = ((mu*ksi+gamma1)/ksi)^(-(mu+gamma1/ksi)*theta) * mu^(mu*theta) * (ksi*nu/gamma1)^(-gamma1/ksi*theta) * gamma(1-(sigma-1)/theta)^(theta/(sigma-1));

% Initialize output variables
l = zeros(n,T);
u = zeros(n,T);
w = zeros(n,T);
phi = zeros(n,T);
tau = zeros(n,T);
realgdp = zeros(n,T);

%% 2. Simulate the model backwards

% Initial guess for Lhat
l_loop = popdens(earth_indices);

% Calculate equilibrium distribution for each period

% Outer loop
for t = 1:T
    disp(['t=' num2str(-t)])    

    % Next period's productivity
    if (t > 1)
        taunext = tau(:,t-1);
    else
        taunext = tau0;
    end;
    
    % Solve for Lhat
    
    error = 1e+10;
    
    % Pre-computed quantities used in the while loop
    aa = a_norm.^((theta^2)/(1+2*theta));
    aa2 = a_norm.^((1+theta)/((khi+Omega*(1+theta)/(1+2*theta)+theta/(1+2*theta)*gamma1/(ksi*gamma2))*(1+2*theta)));
    exponent_l = (1-lambda*theta+(1+theta)/(1+2*theta)*(alpha-1+(lambda+gamma1/ksi-(1-mu))*theta));
    input_integral_outer = aa .* H.^((theta-theta^2*Omega)/(1+2*theta)) .*...
                taunext.^((1+theta)/(gamma2*(1+2*theta))) .* m2.^(-theta^2/(1+2*theta));
    input_integral_outer(isnan(input_integral_outer)) = 0;
    input_l_inner = H.^(-(1+Omega*(1+theta))/((khi+Omega*(1+theta)/(1+2*theta)+theta/(1+2*theta)*gamma1/(ksi*gamma2))*(1+2*theta))) .*...
                        taunext.^(1/((khi+Omega*(1+theta)/(1+2*theta)+theta/(1+2*theta)*gamma1/(ksi*gamma2))*gamma2*(1+2*theta))) .*...
                        m2.^(-(1+theta)/((khi+Omega*(1+theta)/(1+2*theta)+theta/(1+2*theta)*gamma1/(ksi*gamma2))*(1+2*theta)));
    input_l_inner(H == 0) = 0;
    
    % Inner loop - solve for l using equation (40)
    while (error >= 1)        
        l_old = l_loop;
        input_integral_inner = input_integral_outer .*...
            l_loop.^(exponent_l - Omega*theta^2/(1+2*theta) - theta*(1+theta)/(1+2*theta)*gamma1/(ksi*gamma2));
        input_integral_inner(l_loop == 0) = 0;
        
        % This operation (the matrix product) is really the bottleneck of the inner loop
        rhs = trmult_reduced*input_integral_inner;
        
        l_loop = aa2 .* input_l_inner .* rhs .^(1/((khi+Omega*(1+theta)/(1+2*theta)+theta/(1+2*theta)*gamma1/(ksi*gamma2))*theta));
        error = sum((l_loop - l_old).^2);

    end;
    
    % Rescale L so that H*L sum to lbar
    l(:,t) = l_loop / sum(H.*l_loop) * lbar;
    
    % Now that l(:,:,t) is computed, compute other quantities
        
    % Back out productivity using equation (39)
    tau(:,t) = ((mu+gamma1/ksi)/(gamma1/ksi)*nu)^((theta*gamma1/ksi)/gamma2) *...
        taunext.^(1/gamma2) .* l(:,t).^(-theta*gamma1/(ksi*gamma2));
    avgprodtogamma2 = sum(tau(:,t)) / n;
    tau(:,t) = avgprodtogamma2^(gamma2-1) * tau(:,t);
    
    % Calculate utility
    u(:,t) = m2 .* l(:,t).^Omega .* (kappa1^(1/Omega) *...
        ((mu+gamma1/ksi)/(gamma1/ksi)*nu)^(gamma1/(ksi*gamma2)) * (sum(tau(:,t))/n)^(1/theta*(1-1/gamma2)) *...
        (lbar/sum(H.*l_loop))^(1/theta-2*lambda+(alpha-1+(lambda+gamma1/ksi-(1-mu))*theta)/theta-Omega-gamma1/(ksi*gamma2)));
    
    % Calculate real GDP per capita using equation (22)      
    realgdp(:,t) = u(:,t) ./ a_norm .* l(:,t).^lambda;
    
    % Calculate innovation using equation (12) and (13)
    phi(:,t) = (gamma1/(nu*(gamma1+mu*ksi)))^(1/ksi) * l(:,t).^(1/ksi);  % innovation
 
    % Calculate wage using equation (23)
    w(:,t) = a_norm.^(-theta/(1+2*theta)) .* u(:,t).^(theta/(1+2*theta)) .* H.^(-1/(1+2*theta)) .*...
        tau(:,t).^(1/(1+2*theta)) .* l(:,t).^((alpha-1+(lambda+gamma1/ksi-(1-mu))*theta)/(1+2*theta));
    
    % Wages are normalized relative to wage in Princeton, NJ
    % 3199 = find(earth_indices == sub2ind([180,360],50,106)) is the linear
    % index of Princeton
    w(:,t) = w(:,t) / w(3199,t); 

end;

realgdp(isnan(realgdp)) = 0;
tau(isnan(tau)) = 0;
phi(isnan(phi)) = 0;
w(isnan(w)) = 0;
u(isnan(u)) = 0;
l(isnan(l)) = 0;

end

