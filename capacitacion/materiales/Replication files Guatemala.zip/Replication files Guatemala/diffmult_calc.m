% This code calculates the matrix of diffusion multipliers
% across emerged cells

% set of emerged cells
load('H0.mat');
earth_indices = find(H0 > 0);
n = length(earth_indices);

% diffusion parameter, radius of earth
delta = 0.0015;
rad = 6371;

% calculate matrix
diffmult = zeros(180,360,180,360);
for i = 1:180;
    i
    for j = 1:360;
        if (H0(i,j) > 0)
            for k = 1:180;
                for l = 1:360;
                    if (H0(k,l) > 0)
                        lat1 = i/180*pi;
                        lat2 = k/180*pi;
                        long1 = j/180*pi;
                        long2 = l/180*pi;
                        diffmult(i,j,k,l) = exp(-delta*rad*real(acos(sin(lat1)*sin(lat2)+cos(long1-long2)*cos(lat1)*cos(lat2))));
                    end;
                end;
            end;
        end;
    end;
end;

% reduce dimensionality of matrix
diffmult = reshape(diffmult,180*360,180*360);
diffmult_reduced = diffmult(earth_indices,earth_indices);

save('diffmult_reduced','diffmult_reduced','-v7.3');
