% Script to remove the irrelvant sea cells from trmult once for all

trmult = load('trmult.mat');    % Bilateral trade costs
trmult = trmult.trmult;

load('H0', '-mat');

earth_indices = find(H0(:) > 0);
n = sum(H0(:) > 0);

trmult = reshape(trmult,180*360,180*360);
trmult_reduced = trmult(earth_indices,earth_indices);

save('trmult_reduced','trmult_reduced','-v7.3');
