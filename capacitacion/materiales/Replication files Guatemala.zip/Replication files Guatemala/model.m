function [ l, w, u, tau, phi, realgdp ] = model( H, T )

% Simulate GD model for world with given dist of amenities & productivity
% using procedure described in Section 4 of paper

global a a_norm m2 ubar C_vect tau0 pop0 trmult_reduced earth_indices H0 n alpha theta Omega;

%% 1. Initialize parameters and output

% Normalize population to population density
popdens = pop0;
popdens(earth_indices) =  popdens(earth_indices)./H0(earth_indices);
popdens(isinf(popdens)) = 0;
popdens(isnan(popdens)) = 0;

% Parameter values
lbar = 5.9174e+09; % total population
% lbar = sum(sum(pop0));
lambda = 0.32;     % congestion externalities
gamma1 = 0.319;    % elasticity of tomorrow's productivity w.r.t. today's innovation
gamma2 = 0.99246;  % elasticity of tomorrow's productivity w.r.t. today's productivity
eta = 1;           % parameter driving scale of technology diffusion
mu = 0.8;          % labor share in production
nu = 0.15;         % intercept parameter in innovation cost function   % nu = 0.15;
ksi = 125;         % elasticity of innovation costs w.r.t. innovation
sigma = 4;         % elasticity of substitution
rad = 6371;        % radius of Earth
psi = 1.8;         % subjective wellbeing parameter
khi = lambda - (alpha-1+(lambda+gamma1/ksi-(1-mu))*theta) / (1+2*theta);
kappa1 = ((mu*ksi+gamma1)/ksi)^(-(mu+gamma1/ksi)*theta) * mu^(mu*theta) * (ksi*nu/gamma1)^(-gamma1/ksi*theta) * gamma(1-(sigma-1)/theta)^(theta/(sigma-1));

% Calculate utility from subjective wellbeing
u0 = exp(psi*ubar(earth_indices));

% Back out amenities
a_norm = a.*u0;

%% Change migration costs in counterfactual
% If uniform change
    % m2 = m2.^0;
 
%% Initialize output variables
l = zeros(n,T);
w = zeros(n,T);
phi = zeros(n,T);
realgdp = zeros(n,T);
tau = zeros(n,T);
u = zeros(n,T);
uhat = zeros(n,T);

%% 2. Simulate the model

% Update productivity from period 0 to period 1 levels according to
% equation (8) and (12) and (13)
avgprod = sum(sum(tau0)) / n;
% load('diffmult_reduced.mat');
% avgprod = diffmult_reduced * tau0;
tau(:,1) = eta * tau0.^gamma2 .* avgprod.^(1-gamma2) .* (gamma1/(nu*(gamma1+mu*ksi)) * popdens(earth_indices)).^(gamma1*theta/ksi);

% Initial guess for uhat
uhat_loop = 1/n*ones(n,1);

% Calculate equilibrium distribution for each period

% Outer loop
for t = 1:T
    disp(['t=' num2str(t)])    

    % Solve for uhat using equation (51)
    
    error = 1e+10;

    % Pre-computed quantities used in the while loop
    aa = a_norm.^((theta^2)/(1+2*theta));
    aa2 = a_norm.^((1+theta)/((khi/Omega+(1+theta)/(1+2*theta))*(1+2*theta)));
    exponent_l = (1-lambda*theta+(1+theta)/(1+2*theta)*(alpha-1+(lambda+gamma1/ksi-(1-mu))*theta));
    input_integral_outer = aa .* (H.^(theta/(1+2*theta)-1+lambda*theta-(1+theta)/(1+2*theta)*(alpha-1+(lambda+gamma1/ksi-(1-mu))*theta))) .*...
               tau(:,t).^((1+theta)/(1+2*theta)) .* m2.^(-exponent_l/Omega);
    % Simplify 
    %input_integral_outer = aa.* (H.^(theta/(1+2*theta)-exponent_l)).*...
    %            tau(:,t).^((1+theta)/(1+2*theta)).* m2.^(-exponent_l/Omega);
    
    input_integral_outer(isnan(input_integral_outer)) = 0;
    input_uhat_inner = H.^((lambda-(alpha+(lambda+gamma1/ksi-(1-mu))*theta)/(1+2*theta))/(khi/Omega+(1+theta)/(1+2*theta))) .*...
                        tau(:,t).^(1/((khi/Omega+(1+theta)/(1+2*theta))*(1+2*theta))) .*...
                        m2.^(khi/(Omega*(khi/Omega+(1+theta)/(1+2*theta))));
    input_uhat_inner(H == 0) = 0;
    
    % Inner loop
    while (error >= 1e-02)
        uhat_old = uhat_loop;
        input_integral_inner = input_integral_outer .* uhat_loop.^(exponent_l/Omega - theta^2/(1+2*theta));
        input_integral_inner(uhat_loop == 0) = 0;
        
        % This operation (the matrix product) is really the bottleneck of the inner loop
        rhs = trmult_reduced*input_integral_inner;
        
        uhat_loop = aa2 .* input_uhat_inner .* rhs .^(1/(khi*theta/Omega + theta*(1+theta)/(1+2*theta)));
        error = sum((uhat_loop - uhat_old).^2);

    end;
    
    uhat(:,t) = uhat_loop;

    % Solve for u using equation (53)
    u(:,t) = uhat(:,t) / (lbar / sum(uhat(:,t).^(1/Omega).*m2.^(-1/Omega)))^...
        (Omega*((1/Omega*((lambda+(1-mu)-gamma1/ksi)*theta-alpha)+theta)/theta-1));


    % Solve for population using equation (7)
    l(:,t) = H.^(-1) .* u(:,t).^(1/Omega) .* m2.^(-1/Omega);
    
    % Rescale L so that H*L sum to lbar
    l(:,t) = l(:,t) / sum(H.*l(:,t)) * lbar;
    
    % Now that l(:,:,t) is computed, compute other quantities
        
    % Calculate innovation using equation (12) and (13)
    phi(:,t) = (gamma1/(nu*(gamma1+mu*ksi)))^(1/ksi) * l(:,t).^(1/ksi);    % innovation
 
    % Calculate wage using equation (23)
    w(:,t) = a_norm.^(-theta/(1+2*theta)) .* u(:,t).^(theta/(1+2*theta)) .* H.^(-1/(1+2*theta)) .*...
        tau(:,t).^(1/(1+2*theta)) .* l(:,t).^((alpha-1+(lambda+gamma1/ksi-(1-mu))*theta)/(1+2*theta));
    
    % Wages are normalized relative to wage in Princeton, NJ
    % 3199 = find(earth_indices == sub2ind([180,360],50,106)) is the linear
    % index of Princeton
    w(:,t) = w(:,t) / w(3199,t); 
         
    % Calculate real GDP per capita using equation (22)       
    realgdp(:,t) = u(:,t) ./ a_norm .* l(:,t).^lambda;

    % Calculate trade to GDP ratio in periods 1 and T using equation (12),
    % (13), (14), (17) and (19) and then (21)
    if ((t == 1) || (t == T))
        display('TOTAL IMPORTS TO WORLD GDP');
        trsharesum = trmult_reduced *...
            (tau(:,t).*l(:,t).^(alpha-(1-mu-gamma1/ksi)*theta).*w(:,t).^(-theta));
        domtrade = 0;
        for i = 1:n;
            for j = 1:n;
                if (C_vect(i) == C_vect(j))
                    domtrade = domtrade +...
                        tau(j,t)*l(j,t)^(alpha-(1-mu-gamma1/ksi)*theta)*w(j,t)^(-theta) *...
                        trmult_reduced(i,j) / trsharesum(i) * w(i,t) * H(i) * l(i,t);
                end;
            end;
        end;
        1 - domtrade / sum(w(:,t).*H.*l(:,t))
    end;

    % Update productivity according to equation (8)
    if (t < T)
        avgprod = sum(tau(:,t)) / n;
        % avgprod = diffmult_reduced * tau(:,t);
        tau(:,t+1) = eta * tau(:,t).^gamma2 .* avgprod.^(1-gamma2) .* phi(:,t).^(gamma1*theta);
    end;
    
end;

realgdp(isnan(realgdp)) = 0;
tau(isnan(tau)) = 0;
phi(isnan(phi)) = 0;
w(isnan(w)) = 0;
l(isnan(l)) = 0;

end

