% Calculate instantaneous trade costs for each location in the Earth
% where cost function parameters are assigned based on Allen and Arkolakis (2013)

clear all;

xbar = 360;
ybar = 180;

% parameter values based on Allen and Arkolakis (2014)
water = 0.0779;
no_water = 0.779;
rail = 0.1434;
no_rail = 0.4302;
road_major = 0.5636;
road_nonmajor = 1.1272;
no_road = 1.9726;

% load data
data = csvread('natural_features.csv');

% assign values to locations
Sig = zeros(ybar,xbar);
for i = 1:length(data(:,1));
    j = round(90.5-data(i,1));
    k = round(data(i,2)+180.5);
    Sig(j,k) = (rail^data(i,3) * no_rail^(1-data(i,3))) *...
        (road_major^data(i,5) * road_nonmajor^(data(i,4)-data(i,5)) * no_road^(1-data(i,4))) *...
        (water^min([data(i,6)+(1-data(i,7)) 1]) * no_water^(1-min([data(i,6)+(1-data(i,7)) 1])));
end;

% display and write results into csv file
csvwrite('Sig.csv',Sig);
figure
imagesc(Sig);
colorbar
